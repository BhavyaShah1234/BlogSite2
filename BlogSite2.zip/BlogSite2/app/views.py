from django.shortcuts import render, redirect
from django.db.models import Q
from django.http import HttpResponse
from . import models
from . import utils
import json


# Create your views here.
def index(request):
    if request.GET.get('q') is not None:
        q = request.GET.get('q')
    else:
        q = ''
    topics = models.Topic.objects.all()
    blogs = models.Blog.objects.filter(Q(title__icontains=q) |
                                       Q(topic__name__icontains=q) |
                                       Q(email__username__icontains=q))
    c = {'topics': topics, 'blogs': blogs, 'q': q}
    return render(request, 'index.html', context=c)


def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        query = models.User.objects.filter(username=username, email=email, password=password)
        if len(query) == 0:
            query = models.User(username=username, email=email, password=password)
            query.save()
            return redirect(f'/login/?username={username}')
        return redirect('/signup/')
    return render(request, 'signup.html')


def validate(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        query = models.User.objects.filter(username=username)
        if len(query) == 0:
            query = models.User.objects.filter(email=email)
            if len(query) == 0:
                data = json.dumps({'username': True, 'email': True})
                return HttpResponse(data, content_type='application/json')
            data = json.dumps({'username': True, 'email': False})
            return HttpResponse(data, content_type='application/json')
        data = json.dumps({'username': False, 'email': False})
        return HttpResponse(data, content_type='application/json')
    return redirect('/')


def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        query = models.User.objects.filter(email=email, password=password)
        if len(query) != 0:
            query = models.User.objects.get(email=email)
            username = query.username
            query.active = True
            query.save()
            return redirect(f'/home/{username}/')
        return redirect('/signup/?error=no-such-user')
    return render(request, 'login.html')


def home(request, username):
    if request.method == 'GET':
        query = models.User.objects.filter(username=username)
        if len(query) != 0:
            query = models.User.objects.get(username=username)
            if query.active:
                if request.GET.get('q') is None:
                    query = False
                    blogs = models.Blog.objects.filter(email__username__icontains=username)
                    topics = models.Topic.objects.all()
                    c = {'username': username, 'blogs': blogs, 'query': query, 'topics': topics}
                    return render(request, 'home.html', context=c)
                query = True
                q = request.GET.get('q')
                blogs = models.Blog.objects.filter(Q(topic__name__icontains=q) |
                                                   Q(email__username__icontains=q) |
                                                   Q(title__icontains=q))
                topics = models.Topic.objects.all()
                c = {'username': username, 'blogs': blogs, 'query': query, 'q': q, 'topics': topics}
                return render(request, 'home.html', context=c)
            return redirect(f'/login/?username={username}')
        return redirect(f'/signup/?username={username}')
    query = models.User.objects.get(username=username)
    query.active = False
    query.save()
    return redirect(f'/?logout={username}')


def new(request, username):
    if request.method == 'POST':
        blog_id = utils.generate_blog_id()
        email = models.User.objects.get(username=username)
        topic = models.Topic.objects.get(name=request.POST['topic'])
        title = request.POST['title']
        body = request.POST['body']
        query = models.Blog.objects.filter(title=title)
        if len(query) == 0:
            query = models.Blog(blog_id=blog_id, email=email, topic=topic, title=title, body=body)
            query.save()
            return redirect(f'/home/{username}/')
        query = models.Blog.objects.get(title=title)
        blog_id = query.blog_id
        return redirect(f'/home/{username}/edit/{blog_id}/')
    query = models.User.objects.filter(username=username)
    if len(query) != 0:
        query = models.User.objects.get(username=username)
        if query.active:
            topics = models.Topic.objects.all()
            c = {'username': username, 'topics': topics}
            return render(request, 'new.html', context=c)
        return redirect(f'/login/?username={username}')
    return redirect(f'/signup/?username={username}')


def edit(request, username, blog_id):
    if request.method == 'POST':
        topic = models.Topic.objects.get(name=request.POST['topic'])
        title = request.POST['title']
        body = request.POST['body']
        query = models.Blog.objects.get(blog_id=blog_id)
        if query.topic != topic or query.body != body or topic != topic:
            query.topic = topic
            query.title = title
            query.body = body
            query.save()
            return redirect(f'/home/{username}/')
        return redirect(f'/home/{username}')
    query = models.User.objects.filter(username=username)
    if len(query) != 0:
        query = models.User.objects.get(username=username)
        if query.active:
            topics = models.Topic.objects.all()
            blog = models.Blog.objects.get(blog_id=blog_id)
            c = {'username': username, 'topics': topics, 'blog': blog}
            return render(request, 'edit.html', context=c)
        return redirect(f'/login/?username={username}')
    return redirect(f'/signup/?username={username}')


def delete(request, username, blog_id):
    if request.method == 'POST':
        query = models.Blog.objects.get(blog_id=blog_id)
        query.delete()
        return redirect(f'/home/{username}')
    query = models.User.objects.filter(username=username)
    if len(query) != 0:
        query = models.User.objects.get(username=username)
        if query.active:
            query = models.Blog.objects.get(blog_id=blog_id)
            title = query.title
            topics = models.Topic.objects.all()
            c = {'username': username, 'title': title, 'topics': topics}
            return render(request, 'delete.html', context=c)
        return redirect(f'/login/?username={username}')
    return redirect(f'/signup/?username={username}')


def new_topic(request, username):
    if request.method == 'POST':
        name = request.POST['name']
        query = models.Topic.objects.filter(name=name)
        if len(query) == 0:
            query = models.Topic.objects.create(name=name)
            query.save()
            return redirect(f'/home/{username}/')
        return redirect(f'/home/{username}/?q={name}')
    query = models.User.objects.filter(username=username)
    if len(query) != 0:
        query = models.User.objects.get(username=username)
        if query.active:
            topics = models.Topic.objects.all()
            c = {'username': username, 'topics': topics}
            return render(request, 'topic.html', context=c)
        return redirect(f'/login/?username={username}')
    return redirect(f'/signup/?username={username}')


def read(request, username, blog_id):
    if request.method == 'GET':
        query = models.User.objects.filter(username=username)
        if len(query) == 0:
            return redirect(f'/signup/?username={username}')
        query = models.User.objects.get(username=username)
        if query.active:
            query = models.Blog.objects.filter(blog_id=blog_id)
            if len(query) == 0:
                return redirect(f'/home/{username}/?q={blog_id}')
            query = models.Blog.objects.get(blog_id=blog_id)
            title = query.title
            body = query.body
            author = query.email
            updated = query.updated
            topics = models.Topic.objects.all()
            c = {'username': username,
                 'title': title,
                 'topics': topics,
                 'author': author,
                 'updated': updated,
                 'body': body}
            return render(request, 'read.html', context=c)
        return redirect(f'/login/?username={username}')
    query = models.User.objects.get(username=username)
    if query.active:
        query.active = False
        return redirect(f'/?logout={username}')
    return redirect('/login/')

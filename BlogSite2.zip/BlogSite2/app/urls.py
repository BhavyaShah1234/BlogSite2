from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup, name='signup'),
    path('validation/', views.validate, name='validation'),
    path('login/', views.login, name='login'),
    path('home/<str:username>/', views.home, name='home'),
    path('home/<str:username>/new/', views.new, name='new'),
    path('home/<str:username>/edit/<str:blog_id>/', views.edit, name='edit'),
    path('home/<str:username>/delete/<str:blog_id>/', views.delete, name='delete'),
    path('home/<str:username>/topic/', views.new_topic, name='topic'),
    path('read/<str:username>/<str:blog_id>/', views.read, name='read'),
]

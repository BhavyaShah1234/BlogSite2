from django.utils.crypto import get_random_string
from . import models
import string


def generate_blog_id():
    blog_id = get_random_string(length=10,
                                allowed_chars=string.digits + string.ascii_lowercase + string.ascii_uppercase)
    query = models.Blog.objects.filter(blog_id=blog_id)
    if len(query) == 0:
        return blog_id
    generate_blog_id()

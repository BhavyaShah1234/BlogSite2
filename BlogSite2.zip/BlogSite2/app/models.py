from django.db import models


# Create your models here.
class User(models.Model):
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(max_length=100, primary_key=True)
    password = models.CharField(max_length=20)
    active = models.BooleanField(default=False)

    def __str__(self):
        return self.username


class Topic(models.Model):
    name = models.CharField(max_length=100, primary_key=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Blog(models.Model):
    blog_id = models.CharField(max_length=10, primary_key=True)
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    email = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=500, unique=True)
    body = models.CharField(max_length=10000)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated', '-created']

    def __str__(self):
        return self.title
